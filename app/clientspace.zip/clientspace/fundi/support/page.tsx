import React from "react";

export default function SupportPage() {
    return <div>Hello world</div>;
}